"""Виджет погоды для Windows 10 — точка входа."""

from __future__ import annotations

import sys
from typing import Iterable

import requests
from PyQt6.QtCore import QEvent, QObject, Qt, QPoint, QThread, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap
from PyQt6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from config import load_settings, save_settings
from weather_service import (
    DailyForecast,
    WeatherBundle,
    WeatherFetchWorker,
    WeatherService,
    verify_api_key,
)

STYLESHEET = """
QWidget#GlassPanel {
    background-color: rgba(32, 32, 32, 242);
    border: 1px solid rgba(255, 255, 255, 30);
    border-radius: 22px;
}

QLabel {
    color: #f0f0f0;
    background: transparent;
    font-family: "Segoe UI";
}

QLabel#CityTitle {
    font-size: 26px;
    font-weight: 600;
    color: #ffffff;
}

QLabel#TempMain {
    font-size: 68px;
    font-weight: 200;
    color: #ffffff;
    letter-spacing: -3px;
}

QLabel#Description {
    font-size: 15px;
    color: #b0b0b0;
}

QLabel#Meta {
    font-size: 12px;
    color: #8a8a8a;
    line-height: 1.4;
}

QLabel#SectionTitle {
    font-size: 11px;
    font-weight: 600;
    color: #707070;
    letter-spacing: 1px;
}

QLabel#DayName {
    font-size: 12px;
    font-weight: 600;
    color: #a0a0a0;
}

QLabel#DayTemp {
    font-size: 13px;
    font-weight: 500;
    color: #ececec;
}

QLabel#DayDesc {
    font-size: 10px;
    color: #757575;
}

QLabel#Hint {
    font-size: 11px;
    color: #666666;
}

QLineEdit#Search {
    background-color: rgba(255, 255, 255, 10);
    border: 1px solid rgba(255, 255, 255, 16);
    border-radius: 14px;
    padding: 11px 16px;
    font-family: "Segoe UI";
    font-size: 13px;
    color: #f0f0f0;
    selection-background-color: #3d8fd9;
}

QLineEdit#Search:focus {
    border-color: rgba(77, 163, 255, 170);
    background-color: rgba(255, 255, 255, 14);
}

QLineEdit#Search:disabled {
    color: #777777;
}

QLineEdit#Search::placeholder {
    color: #666666;
}

QPushButton#SearchBtn {
    background-color: #3d8fd9;
    color: #ffffff;
    border: none;
    border-radius: 14px;
    padding: 11px 20px;
    font-family: "Segoe UI";
    font-size: 13px;
    font-weight: 600;
    min-width: 76px;
}

QPushButton#SearchBtn:hover:enabled {
    background-color: #4d9ae6;
}

QPushButton#SearchBtn:pressed:enabled {
    background-color: #3580c4;
}

QPushButton#SearchBtn:disabled {
    background-color: rgba(61, 143, 217, 90);
    color: rgba(255, 255, 255, 130);
}

QPushButton#CloseBtn {
    background-color: transparent;
    color: #909090;
    border: none;
    border-radius: 10px;
    font-family: "Segoe UI";
    font-size: 18px;
    min-width: 34px;
    max-width: 34px;
    min-height: 34px;
    max-height: 34px;
    padding: 0;
}

QPushButton#CloseBtn:hover {
    background-color: rgba(232, 68, 68, 100);
    color: #ffffff;
}

QPushButton#CloseBtn:pressed {
    background-color: rgba(180, 50, 50, 150);
}

QProgressBar#LoadingBar {
    background-color: rgba(255, 255, 255, 8);
    border: none;
    border-radius: 2px;
    min-height: 3px;
    max-height: 3px;
}

QProgressBar#LoadingBar::chunk {
    background-color: qlineargradient(
        x1:0, y1:0, x2:1, y2:0,
        stop:0 #3d8fd9, stop:1 #5ab0ff
    );
    border-radius: 2px;
}

QFrame#ForecastCard {
    background-color: rgba(255, 255, 255, 8);
    border: 1px solid rgba(255, 255, 255, 10);
    border-radius: 14px;
}

QFrame#ForecastCard:hover {
    background-color: rgba(255, 255, 255, 14);
    border-color: rgba(255, 255, 255, 20);
}

QFrame#ForecastPanel {
    background-color: rgba(0, 0, 0, 40);
    border-radius: 16px;
    border: 1px solid rgba(255, 255, 255, 6);
}
"""


def _enable_windows_blur(hwnd: int) -> None:
    """Размытие за окном на Windows 10/11 (если поддерживается)."""
    try:
        import ctypes

        class ACCENTPOLICY(ctypes.Structure):
            _fields_ = [
                ("AccentState", ctypes.c_int),
                ("AccentFlags", ctypes.c_int),
                ("GradientColor", ctypes.c_int),
                ("AnimationId", ctypes.c_int),
            ]

        class WINDOWCOMPOSITIONATTRIBDATA(ctypes.Structure):
            _fields_ = [
                ("Attribute", ctypes.c_int),
                ("Data", ctypes.POINTER(ACCENTPOLICY),
                ),
                ("SizeOfData", ctypes.c_size_t),
            ]

        accent = ACCENTPOLICY()
        accent.AccentState = 3  # ACCENT_ENABLE_BLURBEHIND
        accent.AccentFlags = 0
        accent.GradientColor = 0xCC202020  # AABBGGRR, полупрозрачный #202020
        accent.AnimationId = 0

        data = WINDOWCOMPOSITIONATTRIBDATA()
        data.Attribute = 19  # WCA_ACCENT_POLICY
        data.Data = ctypes.pointer(accent)
        data.SizeOfData = ctypes.sizeof(accent)

        ctypes.windll.user32.SetWindowCompositionAttribute(int(hwnd), ctypes.byref(data))
    except Exception:
        pass


class IconLoadWorker(QThread):
    """Загрузка иконок погоды в фоне, чтобы не блокировать UI."""

    finished = pyqtSignal(dict)  # icon_code -> bytes

    def __init__(self, icon_codes: Iterable[str]) -> None:
        super().__init__()
        self._codes = list(dict.fromkeys(icon_codes))

    def run(self) -> None:
        result: dict[str, bytes] = {}
        for code in self._codes:
            if self.isInterruptionRequested():
                return
            try:
                resp = requests.get(WeatherService.icon_url(code), timeout=8)
                if resp.ok:
                    result[code] = resp.content
            except requests.RequestException:
                pass
        self.finished.emit(result)


class ForecastDayCard(QFrame):
    def __init__(
        self,
        day: DailyForecast,
        icon_data: bytes | None = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("ForecastCard")
        self.setFixedSize(68, 112)
        self._icon_label: QLabel

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 10, 6, 10)
        layout.setSpacing(3)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        day_label = QLabel(day.day_name)
        day_label.setObjectName("DayName")
        day_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self._icon_label = QLabel()
        self._icon_label.setFixedSize(36, 36)
        self._icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._set_icon_pixmap(icon_data)

        temp_label = QLabel(f"{day.temp_min:.0f}° / {day.temp_max:.0f}°")
        temp_label.setObjectName("DayTemp")
        temp_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        desc_label = QLabel(day.description[:11])
        desc_label.setObjectName("DayDesc")
        desc_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        desc_label.setWordWrap(True)

        layout.addWidget(day_label)
        layout.addWidget(self._icon_label, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(temp_label)
        layout.addWidget(desc_label)

    def _set_icon_pixmap(self, data: bytes | None) -> None:
        if not data:
            return
        pm = QPixmap()
        if pm.loadFromData(data):
            self._icon_label.setPixmap(
                pm.scaled(
                    36,
                    36,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )


class WeatherWidget(QWidget):
    """Главное окно: UI ↔ WeatherFetchWorker + сохранение города."""

    # Кнопки должны получать клики; всё остальное — перетаскивание окна
    _DRAG_SKIP_TYPES = (QPushButton,)

    def __init__(self) -> None:
        super().__init__()
        self.settings = load_settings()
        self.service = WeatherService(self.settings)
        self._drag_pos: QPoint | None = None
        self._worker: WeatherFetchWorker | None = None
        self._icon_worker: IconLoadWorker | None = None
        self._loading = False
        self._forecast_cards: list[ForecastDayCard] = []
        self._last_forecast: list[DailyForecast] = []

        self._setup_window()
        self._build_ui()
        self._install_drag_handlers(self)
        self._request_weather(self.settings.city)

    def _setup_window(self) -> None:
        self.setWindowTitle("Погода")
        self.setFixedSize(560, 470)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet(STYLESHEET)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        QTimer.singleShot(0, lambda: _enable_windows_blur(int(self.winId())))

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 10, 10, 10)

        self.panel = QFrame()
        self.panel.setObjectName("GlassPanel")
        panel_layout = QVBoxLayout(self.panel)
        panel_layout.setContentsMargins(24, 18, 24, 22)
        panel_layout.setSpacing(14)

        header = QHBoxLayout()
        title = QLabel("ПОГОДА")
        title.setObjectName("SectionTitle")

        self.close_btn = QPushButton("×")
        self.close_btn.setObjectName("CloseBtn")
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.setToolTip("Закрыть")
        self.close_btn.clicked.connect(self.close)

        header.addWidget(title)
        header.addStretch()
        header.addWidget(self.close_btn)
        panel_layout.addLayout(header)

        self.loading_bar = QProgressBar()
        self.loading_bar.setObjectName("LoadingBar")
        self.loading_bar.setTextVisible(False)
        self.loading_bar.setRange(0, 0)
        self.loading_bar.setVisible(False)
        panel_layout.addWidget(self.loading_bar)

        search_row = QHBoxLayout()
        search_row.setSpacing(10)
        self.search_input = QLineEdit(self.settings.city)
        self.search_input.setObjectName("Search")
        self.search_input.setPlaceholderText("Введите город...")
        self.search_input.returnPressed.connect(self._on_search)

        self.search_btn = QPushButton("Найти")
        self.search_btn.setObjectName("SearchBtn")
        self.search_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.search_btn.clicked.connect(self._on_search)

        search_row.addWidget(self.search_input, stretch=1)
        search_row.addWidget(self.search_btn)
        panel_layout.addLayout(search_row)

        self.city_label = QLabel(self.settings.city)
        self.city_label.setObjectName("CityTitle")

        current_row = QHBoxLayout()
        current_row.setSpacing(14)
        self.icon_main = QLabel()
        self.icon_main.setFixedSize(92, 92)
        self.icon_main.setAlignment(Qt.AlignmentFlag.AlignCenter)

        temp_col = QVBoxLayout()
        temp_col.setSpacing(4)
        self.temp_label = QLabel("—°")
        self.temp_label.setObjectName("TempMain")
        self.desc_label = QLabel("Загрузка...")
        self.desc_label.setObjectName("Description")
        temp_col.addWidget(self.temp_label)
        temp_col.addWidget(self.desc_label)

        current_row.addWidget(self.icon_main)
        current_row.addLayout(temp_col)
        current_row.addStretch()

        self.meta_label = QLabel("")
        self.meta_label.setObjectName("Meta")
        self.meta_label.setWordWrap(True)

        panel_layout.addWidget(self.city_label)
        panel_layout.addLayout(current_row)
        panel_layout.addWidget(self.meta_label)

        forecast_panel = QFrame()
        forecast_panel.setObjectName("ForecastPanel")
        forecast_layout = QVBoxLayout(forecast_panel)
        forecast_layout.setContentsMargins(14, 14, 14, 16)
        forecast_layout.setSpacing(10)

        forecast_title = QLabel("Прогноз на неделю")
        forecast_title.setObjectName("SectionTitle")
        forecast_layout.addWidget(forecast_title)

        self.forecast_container = QWidget()
        self.forecast_grid = QHBoxLayout(self.forecast_container)
        self.forecast_grid.setContentsMargins(0, 0, 0, 0)
        self.forecast_grid.setSpacing(6)
        self.forecast_grid.setAlignment(Qt.AlignmentFlag.AlignCenter)
        forecast_layout.addWidget(self.forecast_container)

        panel_layout.addWidget(forecast_panel)

        if not self.service.has_api_key:
            hint_text = "Демо-режим · укажите API_KEYS в config.py"
        else:
            ok, hint_text = verify_api_key()
            hint_text = "" if ok else hint_text
        if hint_text:
            hint = QLabel(hint_text)
            hint.setObjectName("Hint")
            hint.setWordWrap(True)
            hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            panel_layout.addWidget(hint)

        outer.addWidget(self.panel)
        self._install_drag_handlers(self)
        self._install_drag_handlers(self.panel)

    def _install_drag_handlers(self, root: QWidget) -> None:
        root.installEventFilter(self)
        for child in root.findChildren(QWidget):
            if isinstance(child, self._DRAG_SKIP_TYPES):
                continue
            child.installEventFilter(self)

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:
        if isinstance(obj, self._DRAG_SKIP_TYPES):
            return super().eventFilter(obj, event)

        if event.type() == QEvent.Type.MouseButtonPress:
            if event.button() == Qt.MouseButton.LeftButton:
                self._drag_pos = (
                    event.globalPosition().toPoint() - self.frameGeometry().topLeft()
                )
        elif event.type() == QEvent.Type.MouseMove:
            if (
                event.buttons() == Qt.MouseButton.LeftButton
                and self._drag_pos is not None
            ):
                self.move(event.globalPosition().toPoint() - self._drag_pos)
        elif event.type() == QEvent.Type.MouseButtonRelease:
            self._drag_pos = None

        return super().eventFilter(obj, event)

    def _set_loading(self, active: bool) -> None:
        self._loading = active
        self.loading_bar.setVisible(active)
        self.search_btn.setEnabled(not active)
        self.search_input.setEnabled(not active)
        if active:
            self.desc_label.setText("Загрузка данных...")
            self.meta_label.setText("")

    def _request_weather(self, city: str) -> None:
        city = city.strip()
        if not city:
            return

        self.city_label.setText(city)
        self.temp_label.setText("—°")
        self.icon_main.clear()
        self._clear_forecast()
        self._set_loading(True)

        use_mock = not self.service.has_api_key
        self._start_weather_worker(city, use_mock=use_mock)

    def _on_search(self) -> None:
        city = self.search_input.text().strip()
        if not city or self._loading:
            return

        self.settings.city = city
        save_settings(self.settings)
        self.service.settings = self.settings
        self._request_weather(city)

    def _start_weather_worker(self, city: str, *, use_mock: bool) -> None:
        self._stop_worker(self._worker)
        self._worker = WeatherFetchWorker(self.service, city, use_mock=use_mock)
        self._worker.finished.connect(self._on_weather_loaded)
        self._worker.failed.connect(self._on_weather_failed)
        self._worker.start()

    @staticmethod
    def _stop_worker(worker: QThread | None) -> None:
        if worker is None or not worker.isRunning():
            return
        worker.requestInterruption()
        worker.quit()
        worker.wait(2500)

    def _on_weather_loaded(self, bundle: WeatherBundle) -> None:
        self._set_loading(False)

        self.settings.city = bundle.current.city
        self.service.settings = self.settings
        save_settings(self.settings)
        self.search_input.setText(bundle.current.city)

        self._apply_weather(bundle)
        self._load_icons_async(bundle)

    def _on_weather_failed(self, message: str) -> None:
        self._set_loading(False)
        self.desc_label.setText(message)
        self.meta_label.setText("Повторите поиск или проверьте подключение.")

    def _apply_weather(self, bundle: WeatherBundle) -> None:
        current = bundle.current

        self.city_label.setText(current.city)
        self.temp_label.setText(f"{current.temperature:.0f}°")
        self.desc_label.setText(current.description)
        self.meta_label.setText(
            f"Ощущается как {current.feels_like:.0f}°   ·   "
            f"Влажность {current.humidity}%   ·   "
            f"Ветер {current.wind_speed:.1f} м/с"
        )

        self._last_forecast = bundle.forecast
        self._forecast_cards.clear()
        for day in bundle.forecast:
            card = ForecastDayCard(day)
            self._forecast_cards.append(card)
            self.forecast_grid.addWidget(card)

    def _load_icons_async(self, bundle: WeatherBundle) -> None:
        codes = [bundle.current.icon] + [d.icon for d in bundle.forecast]
        self._stop_worker(self._icon_worker)
        self._icon_worker = IconLoadWorker(codes)
        self._icon_worker.finished.connect(
            lambda data: self._apply_icons(bundle.current.icon, data)
        )
        self._icon_worker.start()

    def _apply_icons(self, main_code: str, data: dict[str, bytes]) -> None:
        main_bytes = data.get(main_code)
        if main_bytes:
            pm = QPixmap()
            if pm.loadFromData(main_bytes):
                self.icon_main.setPixmap(
                    pm.scaled(
                        92,
                        92,
                        Qt.AspectRatioMode.KeepAspectRatio,
                        Qt.TransformationMode.SmoothTransformation,
                    )
                )

        for card, day in zip(self._forecast_cards, self._last_forecast):
            card._set_icon_pixmap(data.get(day.icon))

    def _clear_forecast(self) -> None:
        self._forecast_cards.clear()
        self._last_forecast.clear()
        while self.forecast_grid.count():
            item = self.forecast_grid.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

    def closeEvent(self, event) -> None:
        self._stop_worker(self._worker)
        self._stop_worker(self._icon_worker)
        super().closeEvent(event)

def main() -> int:
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    app = QApplication(sys.argv)
    app.setFont(QFont("Segoe UI", 10))

    widget = WeatherWidget()
    widget.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
