"""Настройки приложения: API-ключ, город по умолчанию."""

from __future__ import annotations

import json
import os
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


def _resolve_app_dir() -> Path:
    """Папка приложения: рядом с .exe после сборки PyInstaller."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = _resolve_app_dir()
SETTINGS_FILE = APP_DIR / "settings.json"
ENV_FILE = APP_DIR / ".env"

# ---------------------------------------------------------------------------
# Ключи OpenWeatherMap (https://openweathermap.org/api)
# При ошибке 401 сервис автоматически пробует следующий ключ из списка.
# ---------------------------------------------------------------------------
API_KEYS = [
    "a7b9798abddc77d20de7b43df12609ce",
    "6dcba9c7f573714029d016ac669837ea",
]
# Основной ключ (для совместимости); обычно совпадает с первым из API_KEYS
API_KEY = API_KEYS[0] if API_KEYS else ""


@dataclass
class AppSettings:
    city: str = "Москва"
    units: str = "metric"  # metric | imperial
    lang: str = "ru"


def _load_dotenv() -> None:
    """Простая загрузка .env без внешних зависимостей."""
    if not ENV_FILE.exists():
        return
    for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def get_api_keys() -> list[str]:
    """Все уникальные ключи: API_KEYS → API_KEY → .env."""
    seen: set[str] = set()
    keys: list[str] = []

    def add(key: str) -> None:
        k = key.strip()
        if k and k not in seen:
            seen.add(k)
            keys.append(k)

    for key in API_KEYS:
        add(key)
    add(API_KEY)
    _load_dotenv()
    add(os.environ.get("OPENWEATHER_API_KEY", ""))
    return keys


def get_api_key() -> str:
    """Первый ключ из списка (рабочий ключ выбирается в WeatherService)."""
    keys = get_api_keys()
    return keys[0] if keys else ""


def load_settings() -> AppSettings:
    if not SETTINGS_FILE.exists():
        return AppSettings()
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        return AppSettings(
            city=data.get("city", "Москва"),
            units=data.get("units", "metric"),
            lang=data.get("lang", "ru"),
        )
    except (json.JSONDecodeError, OSError):
        return AppSettings()


def save_settings(settings: AppSettings) -> None:
    SETTINGS_FILE.write_text(
        json.dumps(asdict(settings), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


# Константы OpenWeatherMap (формат как в документации)
# Пример: http://api.openweathermap.org/data/2.5/forecast?id=524901&appid={API key}
OPENWEATHER_BASE_URL = "http://api.openweathermap.org/data/2.5"
OPENWEATHER_GEO_URL = "http://api.openweathermap.org/geo/1.0/direct"
OPENWEATHER_TEST_CITY_ID = 524901  # Москва — для проверки ключа
REQUEST_TIMEOUT = 12
