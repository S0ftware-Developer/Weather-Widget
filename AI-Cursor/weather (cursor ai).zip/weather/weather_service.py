"""Сервис погоды: Geocoding API, Current Weather и 5 Day / 3 Hour Forecast."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

import requests
from PyQt6.QtCore import QThread, pyqtSignal

from config import (
    OPENWEATHER_BASE_URL,
    OPENWEATHER_GEO_URL,
    OPENWEATHER_TEST_CITY_ID,
    REQUEST_TIMEOUT,
    AppSettings,
    get_api_keys,
)


@dataclass
class GeoLocation:
    name: str
    country: str
    lat: float
    lon: float
    state: str | None = None

    @property
    def display_name(self) -> str:
        if self.state:
            return f"{self.name}, {self.state}, {self.country}"
        return f"{self.name}, {self.country}"


@dataclass
class CurrentWeather:
    city: str
    temperature: float
    feels_like: float
    description: str
    icon: str
    humidity: int
    wind_speed: float


@dataclass
class DailyForecast:
    date: datetime
    day_name: str
    temp_min: float
    temp_max: float
    description: str
    icon: str


@dataclass
class WeatherBundle:
    current: CurrentWeather
    forecast: list[DailyForecast]


class WeatherServiceError(Exception):
    """Базовая ошибка сервиса погоды."""


class ApiKeyMissingError(WeatherServiceError):
    """API-ключ не задан."""


class CityNotFoundError(WeatherServiceError):
    """Город не найден в Geocoding API."""


class NetworkError(WeatherServiceError):
    """Нет сети или сервер недоступен."""


class ApiResponseError(WeatherServiceError):
    """Ошибка ответа API (неверный ключ, лимит и т.д.)."""


WEEKDAY_RU = ("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")


class WeatherService:
    def __init__(self, settings: AppSettings | None = None) -> None:
        self.settings = settings or AppSettings()
        self._api_keys = get_api_keys()
        self._api_key = self._api_keys[0] if self._api_keys else ""
        self._session = requests.Session()

    @property
    def has_api_key(self) -> bool:
        return bool(self._api_keys)

    def fetch_weather(self, city: str | None = None) -> WeatherBundle:
        """
        Полный цикл: геокодирование → текущая погода + дневной прогноз.
        Вызывать из фонового потока (QThread), не из GUI-потока.
        """
        city_query = (city or self.settings.city).strip()
        if not city_query:
            raise WeatherServiceError("Введите название города.")

        if not self.has_api_key:
            raise ApiKeyMissingError(
                "Укажите API-ключи в config.py (список API_KEYS) "
                "или в файле .env (OPENWEATHER_API_KEY)."
            )

        location = self.geocode(city_query)
        weather_data = self._request_json(
            f"{OPENWEATHER_BASE_URL}/weather",
            self._api_params(lat=location.lat, lon=location.lon),
        )
        current = self._parse_current(weather_data, location.display_name)
        city_id = weather_data.get("id")
        forecast = self.fetch_forecast(location, city_id=city_id)
        return WeatherBundle(current=current, forecast=forecast)

    def geocode(self, city: str) -> GeoLocation:
        """Поиск координат по названию города (Geocoding API)."""
        params = self._api_params(q=city, limit=1)
        data = self._request_json(OPENWEATHER_GEO_URL, params)

        if not data:
            raise CityNotFoundError(f'Город «{city}» не найден. Проверьте название.')

        item = data[0]
        return GeoLocation(
            name=item.get("name", city),
            country=item.get("country", ""),
            lat=float(item["lat"]),
            lon=float(item["lon"]),
            state=item.get("state"),
        )

    def fetch_forecast(
        self,
        location: GeoLocation,
        city_id: int | None = None,
        days: int = 7,
    ) -> list[DailyForecast]:
        """
        Прогноз 5 Day / 3 Hour Forecast API.
        Приоритет — официальный формат: forecast?id={city_id}&appid={key}
        """
        if city_id:
            params = self._api_params(id=int(city_id))
        else:
            params = self._api_params(lat=location.lat, lon=location.lon)
        data = self._request_json(f"{OPENWEATHER_BASE_URL}/forecast", params)
        return self._aggregate_forecast(data, max_days=days)

    def _api_params(self, **extra: Any) -> dict[str, Any]:
        """Параметры запроса; appid подставляется в _request_json."""
        return {
            "units": self.settings.units,
            "lang": self.settings.lang,
            **extra,
        }

    def _request_json(self, url: str, params: dict[str, Any]) -> Any:
        keys = self._api_keys or [self._api_key]
        last_401 = False
        last_message = ""

        for key in keys:
            request_params = {**params, "appid": key}
            try:
                response = self._session.get(
                    url, params=request_params, timeout=REQUEST_TIMEOUT
                )
            except requests.Timeout as exc:
                raise NetworkError("Превышено время ожидания. Проверьте интернет.") from exc
            except requests.ConnectionError as exc:
                raise NetworkError(
                    "Нет подключения к интернету. Проверьте сеть и повторите попытку."
                ) from exc
            except requests.RequestException as exc:
                raise NetworkError(f"Ошибка сети: {exc}") from exc

            if response.status_code == 401:
                last_401 = True
                try:
                    body = response.json()
                    last_message = body.get("message", "") if isinstance(body, dict) else ""
                except ValueError:
                    pass
                continue

            if response.status_code == 404:
                raise ApiResponseError("Данные по запросу не найдены.")
            if response.status_code == 429:
                raise ApiResponseError(
                    "Превышен лимит запросов OpenWeatherMap. Попробуйте позже."
                )

            try:
                data = response.json()
            except ValueError as exc:
                raise ApiResponseError("Сервер вернул некорректный ответ.") from exc

            if response.status_code != 200:
                message = (
                    data.get("message", response.reason)
                    if isinstance(data, dict)
                    else response.reason
                )
                raise ApiResponseError(f"Ошибка API ({response.status_code}): {message}")

            self._api_key = key
            return data

        if last_401:
            count = len(keys)
            raise ApiResponseError(
                f"Ни один из {count} API-ключей не принят сервером (401). "
                "Подождите до 2 ч после создания ключа или добавьте новый в API_KEYS. "
                f"{last_message}".strip()
            )
        raise ApiResponseError("Не удалось выполнить запрос к OpenWeatherMap.")

    @staticmethod
    def icon_url(icon_code: str) -> str:
        return f"https://openweathermap.org/img/wn/{icon_code}@2x.png"

    def _parse_current(self, data: dict[str, Any], city_label: str) -> CurrentWeather:
        main = data.get("main", {})
        weather = (data.get("weather") or [{}])[0]
        wind = data.get("wind", {})
        api_name = data.get("name")
        return CurrentWeather(
            city=api_name or city_label.split(",")[0],
            temperature=float(main.get("temp", 0)),
            feels_like=float(main.get("feels_like", 0)),
            description=str(weather.get("description", "")).capitalize(),
            icon=weather.get("icon", "01d"),
            humidity=int(main.get("humidity", 0)),
            wind_speed=float(wind.get("speed", 0)),
        )

    @staticmethod
    def _aggregate_forecast(
        data: dict[str, Any], max_days: int = 7
    ) -> list[DailyForecast]:
        """Группировка 3-часовых интервалов по календарным дням."""
        days: dict[str, list[dict[str, Any]]] = {}
        for item in data.get("list", []):
            dt_txt = item.get("dt_txt", "")
            day_key = dt_txt[:10]
            if day_key:
                days.setdefault(day_key, []).append(item)

        result: list[DailyForecast] = []
        for day_key in sorted(days.keys())[:max_days]:
            items = days[day_key]
            temps_min = [
                i["main"]["temp_min"]
                for i in items
                if "main" in i and "temp_min" in i["main"]
            ]
            temps_max = [
                i["main"]["temp_max"]
                for i in items
                if "main" in i and "temp_max" in i["main"]
            ]
            midday = items[len(items) // 2]
            weather = (midday.get("weather") or [{}])[0]
            dt = datetime.strptime(day_key, "%Y-%m-%d")

            result.append(
                DailyForecast(
                    date=dt,
                    day_name=WEEKDAY_RU[dt.weekday()],
                    temp_min=min(temps_min) if temps_min else 0.0,
                    temp_max=max(temps_max) if temps_max else 0.0,
                    description=str(weather.get("description", "")).capitalize(),
                    icon=weather.get("icon", "01d"),
                )
            )

        if not result:
            raise ApiResponseError("Прогноз погоды недоступен для выбранного города.")

        return result

    @staticmethod
    def mock_weather(city: str) -> WeatherBundle:
        """Демо-данные без API (для разработки UI)."""
        from datetime import timedelta

        weekday_ru = WEEKDAY_RU
        icons = ("01d", "02d", "03d", "10d", "09d", "11d", "13d")
        descriptions = (
            "Ясно",
            "Облачно",
            "Пасмурно",
            "Дождь",
            "Ливень",
            "Гроза",
            "Снег",
        )
        base = datetime.now().replace(hour=12, minute=0, second=0, microsecond=0)
        forecast: list[DailyForecast] = []
        for i in range(7):
            dt = base + timedelta(days=i)
            forecast.append(
                DailyForecast(
                    date=dt,
                    day_name=weekday_ru[dt.weekday()],
                    temp_min=10.0 + i,
                    temp_max=18.0 + i,
                    description=descriptions[i],
                    icon=icons[i],
                )
            )
        current = CurrentWeather(
            city=city,
            temperature=18.0,
            feels_like=16.0,
            description="Переменная облачность",
            icon="02d",
            humidity=62,
            wind_speed=3.4,
        )
        return WeatherBundle(current=current, forecast=forecast)


class WeatherFetchWorker(QThread):
    """
    Фоновая загрузка погоды для PyQt6.
    Не блокирует главный поток интерфейса.
    """

    finished = pyqtSignal(object)  # WeatherBundle
    failed = pyqtSignal(str)

    def __init__(self, service: WeatherService, city: str, *, use_mock: bool = False) -> None:
        super().__init__()
        self._service = service
        self._city = city
        self._use_mock = use_mock

    def run(self) -> None:
        try:
            if self._use_mock:
                bundle = WeatherService.mock_weather(self._city)
            else:
                bundle = self._service.fetch_weather(self._city)
            self.finished.emit(bundle)
        except WeatherServiceError as exc:
            self.failed.emit(str(exc))
        except Exception as exc:
            self.failed.emit(f"Неожиданная ошибка: {exc}")


def verify_api_key() -> tuple[bool, str]:
    """
    Проверка ключей по официальному примеру из документации:
    http://api.openweathermap.org/data/2.5/forecast?id=524901&appid={API key}
    """
    keys = get_api_keys()
    if not keys:
        return False, "API_KEYS не заданы в config.py"

    url = f"{OPENWEATHER_BASE_URL}/forecast"
    failed = 0
    for index, key in enumerate(keys, start=1):
        try:
            response = requests.get(
                url,
                params={"id": OPENWEATHER_TEST_CITY_ID, "appid": key},
                timeout=REQUEST_TIMEOUT,
            )
        except requests.RequestException:
            return False, "Не удалось связаться с OpenWeatherMap (проверьте интернет)"

        if response.status_code == 200:
            if len(keys) > 1:
                return True, f"Активен ключ №{index} из {len(keys)}"
            return True, "Ключ API активен"
        if response.status_code == 401:
            failed += 1
            continue

        data = (
            response.json()
            if response.headers.get("content-type", "").startswith("application/json")
            else {}
        )
        msg = data.get("message", response.reason) if isinstance(data, dict) else response.reason
        return False, f"Ошибка API: {msg}"

    return False, (
        f"Ни один из {failed} ключей не принят (401). "
        "Подождите активации или создайте новый на home.openweathermap.org/api_keys"
    )
