# Сборка WeatherWidget.exe (PyInstaller, один файл, без консоли)
# Запуск: powershell -ExecutionPolicy Bypass -File .\build.ps1

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "==> Установка зависимостей..."
python -m pip install -r requirements.txt pyinstaller --upgrade

Write-Host "==> Сборка exe..."
python -m PyInstaller `
    --noconfirm `
    --clean `
    --onefile `
    --windowed `
    --name "WeatherWidget" `
    --collect-all PyQt6 `
    --hidden-import certifi `
    main.py

Write-Host ""
Write-Host "Готово: dist\WeatherWidget.exe"
Write-Host "Скопируйте exe в любую папку и запускайте двойным щелчком."
